# TheosInstaller-iOS (32bit/64bit)
Install Theos on 32bit or 64bit iOS device with one click. for 32bit device, only work with sdk 9.3

# Usage
`sh theosinst.sh` [Options] [sdks]

Options.

-v : verbose mode

32 : for 32bit device

64 : for 64bit device

Sdks.

9.3

10.3

11.2

# Change Log
Vers 1.4.2
- Fix the script from failing to git clone
